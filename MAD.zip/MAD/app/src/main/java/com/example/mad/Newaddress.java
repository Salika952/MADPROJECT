package com.example.mad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Newaddress extends AppCompatActivity {
    private EditText name,contact,postalcode,address;
    private Button save;

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newaddress);

        databaseReference= FirebaseDatabase.getInstance().getReference("delivery");

        name=(EditText)findViewById(R.id.ET_Name);
        contact=(EditText)findViewById(R.id.ET_Phone);
        address=(EditText)findViewById(R.id.ET_Address);
        postalcode=(EditText)findViewById(R.id.ET_Postal);


        save=(Button)findViewById(R.id.btnSaveNewAddress);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddShippingDetails();
            }
        });
    }

    public void AddShippingDetails(){
        String Name=name.getText().toString();
        String Contact=contact.getText().toString();
        String Postcode=postalcode.getText().toString();
        String Address=address.getText().toString();

        if(TextUtils.isEmpty(Name)){
            Toast.makeText(Newaddress.this,"Plese provide your name!! ",Toast.LENGTH_SHORT).show();
        }if(TextUtils.isEmpty(Contact)) {
            Toast.makeText(Newaddress.this, "Plese provide your phone number for confirm order!!", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(Postcode)) {
            Toast.makeText(Newaddress.this, "Plese provide your post code!!", Toast.LENGTH_SHORT).show();
        }if(TextUtils.isEmpty(Address)) {
            Toast.makeText(Newaddress.this, "Plese provide your address!!", Toast.LENGTH_SHORT).show();}
        else{
            String id=databaseReference.push().getKey();
            delivery cashOndelivery=new delivery(id,Name,Contact,Postcode,Address);
            databaseReference.child(id).setValue(cashOndelivery);

            name.setText("");
            Toast.makeText(Newaddress.this,"Sucesfully Enter your Details!! ",Toast.LENGTH_SHORT).show();

            Intent intent=new Intent(getApplicationContext(),Verify_OTP.class);
            intent.putExtra("Contact",Contact);
            startActivity(intent);

            //startActivity(new Intent(Newaddress.this,MainActivity.class));
            //finish();;

        }
    }
}