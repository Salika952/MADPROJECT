package com.example.mad;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DeliveryAdapter extends RecyclerView.Adapter<DeliveryAdapter.MyviewHolder> {

     Context context;
     ArrayList<delivery> deliver;

    public DeliveryAdapter(Context c,ArrayList<delivery> d){
        context=c;
        deliver=d;
    }

    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.delivery_info,parent,false);
        return new MyviewHolder(LayoutInflater.from(context).inflate(R.layout.delivery_info,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull DeliveryAdapter.MyviewHolder holder, int position) {
        //delivery dDelivery=this.deliver.get(position);

        holder.txtName.setText(deliver.get(position).getName());
        holder.txtContact.setText(deliver.get(position).getContact());
        holder.txtPostalcode.setText(deliver.get(position).getPostalcode());
        holder.txtAddress.setText(deliver.get(position).getAddress());

    }

    @Override
    public int getItemCount() {
        return deliver.size();
    }

    public class MyviewHolder extends RecyclerView.ViewHolder {
        TextView txtName,txtContact,txtPostalcode,txtAddress;

        public MyviewHolder(View itemView) {
            super(itemView);

            txtName=(TextView) itemView.findViewById(R.id.tvName);
            txtContact=(TextView) itemView.findViewById(R.id.tvContact);
            txtPostalcode=(TextView) itemView.findViewById(R.id.tvPostalcode);
            txtAddress=(TextView) itemView.findViewById(R.id.tvAddress);

        }
    }
}
