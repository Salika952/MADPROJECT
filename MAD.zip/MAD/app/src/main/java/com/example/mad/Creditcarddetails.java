package com.example.mad;

public class Creditcarddetails {
    private String id;
    private String cardno;
    private String expirdate;
    private String ccv;
    private String postalcode;
    private String address;
    private String contact;

    public Creditcarddetails(String id, String cardno, String expirdate, String ccv, String postalcode, String address, String contact) {
        this.id = id;
        this.cardno = cardno;
        this.expirdate = expirdate;
        this.ccv = ccv;
        this.postalcode = postalcode;
        this.address = address;
        this.contact = contact;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCardno() {
        return cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public String getExpirdate() {
        return expirdate;
    }

    public void setExpirdate(String expirdate) {
        this.expirdate = expirdate;
    }

    public String getCcv() {
        return ccv;
    }

    public void setCcv(String ccv) {
        this.ccv = ccv;
    }

    public String getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(String postalcode) {
        this.postalcode = postalcode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }



}
